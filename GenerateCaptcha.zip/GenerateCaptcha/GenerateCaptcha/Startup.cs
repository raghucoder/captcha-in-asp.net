﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(GenerateCaptcha.Startup))]
namespace GenerateCaptcha
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
