﻿using System.Web.UI;

namespace GenerateCaptcha.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}